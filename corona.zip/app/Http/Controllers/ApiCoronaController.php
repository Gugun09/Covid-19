<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ApiCoronaController extends Controller
{
    public function index()
    {
    	// Indonesia
    	$response = Http::withHeaders([
		    'x-rapidapi-host' => 'covid-19-coronavirus-statistics.p.rapidapi.com',
			'x-rapidapi-key' => '5454503a60msh847a7977acf6d60p1c0ae1jsn98b1d9437657'
		])->get('https://covid-19-coronavirus-statistics.p.rapidapi.com/v1/stats',[
			'country' => 'Indonesia'
		]);

		$listData = $response['data']['covid19Stats']['0'];

		// return $negara;
    	// return $response->body();


    	// Negara Global
    	$negara = Http::withHeaders([
		    'x-rapidapi-host' => 'covid-19-coronavirus-statistics.p.rapidapi.com',
			'x-rapidapi-key' => '5454503a60msh847a7977acf6d60p1c0ae1jsn98b1d9437657'
		])->get('https://covid-19-coronavirus-statistics.p.rapidapi.com/v1/stats',[
			'country' => ''
		]);

		$negara = $negara['data']['covid19Stats'];


		// Wilayah
		$wilayah = Http::get('http://api.u9.nu/covid19');

		$wilayah = $wilayah['wilayah'];

		// return $wilayah;

		// Total Positif
    	$positif = Http::get('https://api.kawalcorona.com/positif');

    	$positif = $positif['value'];

    	// return $positif;

    	// Total Sembuh
    	$sembuh = Http::get('https://api.kawalcorona.com/sembuh');

    	$sembuh = $sembuh['value'];

    	// return $sembuh;

    	// Total Meninggal
    	$meninggal = Http::get('https://api.kawalcorona.com/meninggal');

    	$meninggal = $meninggal['value'];

    	// return $sembuh;
    	return view('index', compact('negara','listData','wilayah','positif','sembuh','meninggal'));
    }

    public function positif()
    {
    	$positif = Http::get('https://api.kawalcorona.com/meninggal');

    	$positif = $positif['value'];

    	// return $positif;

    	return view('positif', compact('positif'));
    }
}
